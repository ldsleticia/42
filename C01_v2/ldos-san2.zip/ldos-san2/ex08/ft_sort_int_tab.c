/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ldos-san <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/15 18:56:28 by ldos-san          #+#    #+#             */
/*   Updated: 2019/10/16 11:27:20 by ldos-san         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int hold;
	int i;

	i = 0;
	while (i < size && tab[i] != '\0')
	{
		if (tab[i] > tab[i + 1])
		{
			hold = tab[i];
			tab[i] = tab[i + 1];
			tab[i + 1] = hold;
			i = 0;
		}
		else
			i++;
	}
}
